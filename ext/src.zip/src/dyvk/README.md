# dyvk

Wrapper library around [Vulkan-HPP](https://github.com/KhronosGroup/Vulkan-Hpp) for using it and the Vulkan loader dynamically.

Used by [LittleEngineVk](https://github.com/karnkaul/LittleEngineVk) and other projects.
