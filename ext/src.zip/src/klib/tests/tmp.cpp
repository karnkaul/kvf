#include <klib/text_table.hpp>
#include <klib/unit_test.hpp>

#include <print>

namespace {
using namespace klib;

TEST(text_table) {
	auto builder = TextTable::Builder{};
	builder.add_column("zero").add_column("one", TextTable::Align::Right);
	auto table = builder.build();
	table.no_border = true;
	table.push_row({"00", "01", "500"});
	table.push_row({"10", "11"});

	auto str = std::string{};
	table.append_to(str);
	std::print("{}", str);
}
} // namespace
